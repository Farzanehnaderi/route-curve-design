from gui import RouteSurveyingApp
import tkinter as tk

if __name__ == "__main__":
    root = tk.Tk()
    app = RouteSurveyingApp(root)
    root.mainloop()
